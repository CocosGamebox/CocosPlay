package com.halejcwu.text;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.chad.library.BuildConfig;
import com.cocos.vs.platform.*;


public class MainActivity extends Activity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.button).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        Log.i("cocos_platform_sdk----","onClick——start");

        CocosConfig config1 = new CocosConfig()
                .setChannelId("1")
                .setModelName("cocos_game_jar")
                .build();
        CKGameSDK.init(config1);

        //添加测试广告
        if(BuildConfig.DEBUG){
            CKGameSDK.setTestAd(this);
        }

        CKGameSDK.startHomeActivity(this);

        Log.i("cocos_platform_sdk----","onClick--end");
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
