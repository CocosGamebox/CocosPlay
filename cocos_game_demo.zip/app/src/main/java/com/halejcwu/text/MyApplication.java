package com.halejcwu.text;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.support.multidex.MultiDex;
import android.util.Log;

import com.google.android.play.core.splitcompat.SplitCompat;
import com.google.android.play.core.splitcompat.SplitCompatApplication;

/**
 * Created by ruanjingchun on 2019/7/26.
 */
public class MyApplication extends Application {

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        SplitCompat.install(this);
        MultiDex.install(this);
        Log.i("cocos_platform_sdk----","MyApplication attachBaseContext");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("cocos_platform_sdk----","MyApplication onCreate");
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }


}
