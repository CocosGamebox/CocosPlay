# Android-App-Bundle-Demo
Android App Bundle Demo，已在Google Play 验证其最新特性（用java语言实现）
